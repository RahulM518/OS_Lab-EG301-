// create 5 new files using infinite loop
#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
    int a1 = creat("abc1",0744);
    int a2 = creat("abc2",0744);
    int a3 = creat("abc3",0744);
    int a4 = creat("abc4",0744);
    int a5 = creat("abc5",0744);
    printf("fd1=%d\n fd2=%d\n fd3=%d\n fd4=%d\n fd5=%d\n",a1,a2,a3,a4,a5);
    while (1)
    {};
}