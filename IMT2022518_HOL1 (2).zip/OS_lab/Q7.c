// copy onr file into another
#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    char f1[100],f2[100],file_buffer[100];
    for(int i=0; i<100; i++)
    { strcpy(&file_buffer[i],"");}
    int fd1, fd2;
    printf("Enter the filename:");
    scanf("%s",f1);
    fd1 = open(f1, O_RDONLY);
    int x =read (fd1, file_buffer, sizeof(file_buffer));
    printf("Enter the file to be copied into:");
    scanf("%s",f2);
    fd2 = open(f2,O_WRONLY);
     int y=write (fd2, file_buffer, sizeof(file_buffer));
}