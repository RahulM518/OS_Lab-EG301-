// Write a program, call fork and print the parent and child process id.

#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
int main(){
	int res = fork();

	if(res == 0){
		printf("Child pid: %d\n", getpid());
	}
	else{	
		printf("Parent pid: %d\n", getpid());
	}
	return 0;
}