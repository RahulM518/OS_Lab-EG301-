#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>

int main(int argc, char *argv[]){
    int a;
    for (a = 1; a < argc; a++) {
        struct stat buf;
        if (stat(argv[a], &buf) == -1) {
            perror("Error in stat");
            continue;
        }

        printf("%s is ", argv[a]);

        if (S_ISDIR(buf.st_mode)) {
            printf("a directory\n");
        } else if (S_ISLNK(buf.st_mode)) {
            printf("a symlink\n");
        } else if (S_ISREG(buf.st_mode)) {
            printf("a regular file\n");
        } else if (S_ISFIFO(buf.st_mode)) {
            printf("a FIFO\n");
        } else if (S_ISBLK(buf.st_mode)) {
            printf("a block device\n");
        } else if (S_ISCHR(buf.st_mode)) {
            printf("a character device\n");
        } else {
            printf("an unknown file type\n");
        }
    }
    return 0;
}
