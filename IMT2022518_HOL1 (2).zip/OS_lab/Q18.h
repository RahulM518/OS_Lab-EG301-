#include <stdio.h>

#ifndef RECORD_H
#define RECORD_H

struct Record {
    int tickets;
    int t_num;
};

#endif