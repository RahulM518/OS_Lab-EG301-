// Write a program to perform record locking with the
// following implementations:
// a. Implement a write lock.
// b. Implement a read lock.
// Create three records in a file. Whenever you access a particular record, first lock it, then
// modify/access it to avoid race conditions.
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include "Q18.h"

int main(){
    int fd = open("tickets.txt", O_RDWR | O_CREAT, 0744);
    
    int i=0;
    for (i=0; i<4; i++){
        struct Record rec;
        int n;
        rec.t_num=i;

        scanf("%d",&n);
        rec.tickets=n;
        write(fd, &rec, sizeof(struct Record));
    }
   
    printf("Write successsful\n");
    close(fd);

    return 0;
}
// This is a helper program to write a certain number of tickets to the file, which will be used by Q17_main.c