#!bin/sh/bash
echo "1.soft link"
echo "2.hard link"
echo "3.FIFO"
read -p "Enter your choice: "ch

case $ch in
1)
    read -p"Enter the file name:" file_name
    read -p"Enter the soft link file name:" soft_file
    ln -s $file_name $soft_file
    ;;
2)
    read -p"Enter the file name:" file_name
    read -p"Enter the hard link file name:" hard_file
    ln  $file_name $hard_file
    ;;
3)
    read -p"Enter the file name:" file_name
    mkfifo $file_name
    ;;
esac

    
    