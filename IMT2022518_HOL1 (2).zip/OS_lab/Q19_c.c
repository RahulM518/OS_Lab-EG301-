#include <stdio.h>
#include <signal.h>

int main() {
    printf("Process will be stopped\n");
    raise(SIGSTOP);  // Send SIGSTOP signal to itself
    printf("Process resumed from stopped state.\n"); // Doesn't get executed

    return 0;
}
