# Operating-Systems-Codes
This repository contains code for some fundamental concepts related to operating systems, for the first 30 questions.
Written as part of EG301P - Operating Systems Lab course at IIIT-Bangalore.