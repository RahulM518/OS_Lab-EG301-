#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/resource.h>

int main() {
    int pid = getpid();
    
    int priority = getpriority(PRIO_PROCESS, pid);
    printf("Priority of the current process: %d\n", priority);

    int niceValue = 15;

    if (nice(niceValue) == -1) {
        perror("Error changing priority using nice");
        exit(EXIT_FAILURE);
    }

    int newPriority = getpriority(PRIO_PROCESS, pid);
    printf("New priority of the current process: %d\n", newPriority);

    return 0;
}
