#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
    int ch;
    printf("Enter 1 for a soft link of the file: \n");
    printf("Enter 2 for a hard link of the file: \n");
    printf("Enter 3 for a fifo of the file: \n"); // mkfifo library function -> mknod
    printf("Enter choice:");
    scanf("%d", &ch);

    switch(ch)
    {
        case 1:
        {
            char ip[2048], soft_file[2048];
            printf("Enter the file name:");
            scanf("%s", ip);
            printf("Enter the file name <Soft link>:");
            scanf("%s", soft_file);
            int val = symlink(ip, soft_file);
            printf("The return value:%d \n", val);
            break;
        }
        case 2:
        {
            char ip[2048], hard_file[2048];
            printf("Enter the file name:");
            scanf("%s", ip);
            printf("Enter the file name <Hard link>:");
            scanf("%s", hard_file);
            int val = link(ip, hard_file);
            printf("The return value:%d \n", val);
            break;
        }
        case 3:
        {
            char fifo_file[2048];
            printf("Enter the FIFO file name:");
            scanf("%s", fifo_file);
            int val = mknod(fifo_file, S_IFIFO | 0666, 0); //instead of S_IFIFO, you can directly use the value 0010000 (octal) for FIFO creation
            printf("The return value:%d \n", val);
            break;
        }
        default:
        {
            printf("Wrong choice \n");
            break;
        }
    }
    return 0;   
}
