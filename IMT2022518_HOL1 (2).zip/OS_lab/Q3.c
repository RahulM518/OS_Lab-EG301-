#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
    char ip[2048];
    printf("File input -> name:");
    scanf("%s",ip);
    int val = creat(ip, 0744);
    printf("fd: %d\n",val);
}