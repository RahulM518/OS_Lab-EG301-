#include <stdio.h>
#include <unistd.h>

int main() {
    printf("The process will sleep for 5 seconds...\n");
    sleep(5);
    printf("The process has woken up from sleep\n");

    return 0;
}
