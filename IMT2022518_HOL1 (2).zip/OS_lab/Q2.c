#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
    while(1)
    {
    };
}
// ./a.out & -> & is used to run in the background, it returns the pid
// cd /proc/pid will take you to the respective process
// then cat status
// then to kill the process bring it to foreground using fg and ctrl+c
// or do kill pid