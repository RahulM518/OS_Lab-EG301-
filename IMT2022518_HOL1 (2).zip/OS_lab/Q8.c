#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    int fd1; 
    char buff[100];
    fd1 = open ("xyz1",O_RDONLY|O_EXCL);
    while(read(fd1,buff,1)>0)
    {
        if(buff[0]=='\n')
        {
            int x = getchar();
        }
        else{
            printf("%s",buff);
        }
        int c = close(fd1);
    }
}