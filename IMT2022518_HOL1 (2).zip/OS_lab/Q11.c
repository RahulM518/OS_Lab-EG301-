#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
/* Write a program to open a file, duplicate the file descriptor and append the file with both the
// descriptors and check whether the file is updated properly or not.
 a. use dup
 b. use dup2
 c. use fcntl */

int main()
{
     int fd = open("dump/a", O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fd == -1) {
        perror("Error while opening the file");
        exit(EXIT_FAILURE);
    }

    char *msg ="Hello\n";
    write(fd, msg, strlen(msg));

    int fd_dup = dup(fd);
    if (fd_dup == -1) {
        perror("Error duplicating the file descriptor using dup");
        close(fd);
        exit(EXIT_FAILURE);
    }

    int fd_dup2 = dup2(fd, 10); 
    if (fd_dup2 == -1) {
        perror("Error duplicating the file descriptor using dup2");
        close(fd);
        close(fd_dup);
        exit(EXIT_FAILURE);
    }

    int fd_fcntl = fcntl(fd, F_DUPFD, 0);
    if (fd_fcntl == -1) {
        perror("Error duplicating file descriptor using fcntl");
        close(fd);
        close(fd_dup);
        close(fd_dup2);
        exit(EXIT_FAILURE);
    }

    char *msg1 = "msg appended using original descriptor.\n";
    write(fd, msg1, strlen(msg1));

    char *msg2 = "msg appended using duplicated descriptor (dup).\n";
    write(fd_dup, msg2, strlen(msg2));

    char *msg3 = "msg appended using duplicated descriptor (dup2).\n";
    write(fd_dup2, msg3, strlen(msg3));

    char *msg4 = "msg appended using duplicated descriptor (fcntl).\n";
    write(fd_fcntl, msg4, strlen(msg4));

    close(fd);
    close(fd_dup);
    close(fd_dup2);
    close(fd_fcntl);

    return 0;
}