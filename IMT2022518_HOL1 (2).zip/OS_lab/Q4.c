#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
    char ip[2048];
    printf("File input -> name:");
    scanf("%s",ip);
    int op =  open (ip, O_EXCL|O_RDWR);
    printf("fd = %d\n", op);
}