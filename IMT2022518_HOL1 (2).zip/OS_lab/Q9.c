#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    struct stat st;
    stat("xyz",&st);
    printf("Inode number: %ld\n",st.st_ino);
    printf("Number of hard links:%ld\n",st.st_nlink);
    printf("UID:%d\n", st.st_uid);
    printf("GID:%d\n", st.st_gid);
    printf("Size:%ld\n", st.st_size);
    printf("Block size :%ld\n", st.st_blksize);    
    printf("Block count :%ld\n", st.st_blocks);
    printf("Last access time  :%ld\n", st.st_atimensec);   
    printf("Last modification time  :%ld\n", st.st_mtimensec);     
    printf("Last change time  :%ld\n", st.st_ctimensec);   
}