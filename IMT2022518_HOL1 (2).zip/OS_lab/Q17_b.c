// Note: Run Q17_b.c first, then Q17_a.c. It will read the tickets entered in the file,
// increment and write back to the file. It uses write lock.
// Write a program to open a file, store a ticket number and exit. Write a separate program, to
// open the file, implement write lock, read the ticket number, increment the number and print
// the new ticket number then close the file.

# include <stdio.h>
# include <unistd.h>
# include <fcntl.h>
# include <sys/stat.h>

int main(int argc,char*argv[]){
    int n=1;
    scanf("%d", &n);

    int fd = open("tickets.txt", O_WRONLY | O_CREAT, 0744);
    write(fd, &n, sizeof(int));
    printf("Write successsful\n");

    close(fd);
    return 0;
}   