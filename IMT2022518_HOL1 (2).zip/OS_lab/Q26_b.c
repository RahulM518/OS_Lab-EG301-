//Write a program to execute ls -Rl by the following system calls
                // a. execl
                // b. execlp
                // c. execled
                // d. execv
                // e. execvp

#include<stdio.h>
#include<unistd.h>

int main(){
    printf("Executes ls -Rl using execlp\n");
    execlp("ls", "ls","-R", "-l", NULL);
    return(0);
}
// using execlp()