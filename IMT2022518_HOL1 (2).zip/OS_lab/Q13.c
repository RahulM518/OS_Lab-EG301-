#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
    fd_set FDs;
    struct timeval timeout;

    FD_ZERO(&FDs);
    FD_SET(STDIN_FILENO, &FDs);

    timeout.tv_sec = 10;
    timeout.tv_usec = 0;

    printf("Waiting for input\n");

    int res = select(STDIN_FILENO + 1, &FDs, NULL, NULL, &timeout);

    if (res == -1) {
        perror("Error occured");
        return 1;
    } 
    else if (res == 0) {
        printf("No data received within 10 seconds.\n");
    } 
    else {
        if (FD_ISSET(STDIN_FILENO, &FDs)) {
            printf("Data available\n");

            char buffer[256];
            fgets(buffer, sizeof(buffer), stdin);
            printf("Received input: %s", buffer);
        }
    }

    return 0;
}
