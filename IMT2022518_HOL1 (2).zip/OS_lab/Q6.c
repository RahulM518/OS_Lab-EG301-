//i/p in STDIN and o/p in STDOUT
#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    char buff[100];
    for(int i=0; i<100; i++)
    { strcpy(&buff[i],""); }
    int x = read(0, &buff, 100);
    int y = write(0, &buff, 100);
}