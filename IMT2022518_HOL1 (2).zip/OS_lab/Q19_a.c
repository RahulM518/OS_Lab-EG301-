#include <stdio.h>

int main() {
    printf("Running state\n");

    return 0;
}
